package com.adshield.app

import java.util.concurrent.atomic.AtomicLong

object Stats {
    val total = AtomicLong()
    val blocked = AtomicLong()
    @Volatile var running = false

    data class Entry(val domain: String, val blocked: Boolean, val count: Int)

    private val log = LinkedHashMap<String, Entry>()

    @Synchronized
    fun add(domain: String, isBlocked: Boolean) {
        total.incrementAndGet()
        if (isBlocked) blocked.incrementAndGet()
        val old = log.remove(domain)
        log[domain] = Entry(domain, isBlocked, (old?.count ?: 0) + 1)
        if (log.size > 300) {
            val it = log.keys.iterator()
            it.next()
            it.remove()
        }
    }

    @Synchronized
    fun snapshot(): List<Entry> = log.values.toList().asReversed()
}
