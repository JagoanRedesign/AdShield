package com.adshield.app

import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.NumberFormat

class MainActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var powerBtn: View
    private lateinit var ring1: View
    private lateinit var ring2: View
    private lateinit var tvStatus: TextView
    private lateinit var tvHint: TextView
    private lateinit var tvBlocked: TextView
    private lateinit var tvTotal: TextView
    private lateinit var tvPercent: TextView
    private lateinit var tvFilter: TextView
    private var pulse: ValueAnimator? = null
    private var lastRunning: Boolean? = null

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) startVpn()
        }

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        powerBtn = findViewById(R.id.powerBtn)
        ring1 = findViewById(R.id.ring1)
        ring2 = findViewById(R.id.ring2)
        tvStatus = findViewById(R.id.tvStatus)
        tvHint = findViewById(R.id.tvHint)
        tvBlocked = findViewById(R.id.tvBlocked)
        tvTotal = findViewById(R.id.tvTotal)
        tvPercent = findViewById(R.id.tvPercent)
        tvFilter = findViewById(R.id.tvFilter)

        Thread { BlockList.load(applicationContext) }.start()

        powerBtn.setOnClickListener { toggle() }
        findViewById<View>(R.id.btnLog).setOnClickListener { showLog() }
        findViewById<View>(R.id.btnCustom).setOnClickListener { showCustom() }
        findViewById<View>(R.id.btnUpdate).setOnClickListener { updateFilters() }
        findViewById<View>(R.id.btnDns).setOnClickListener { chooseDns() }
    }

    override fun onStart() {
        super.onStart()
        handler.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(ticker)
        pulse?.cancel()
        lastRunning = null
    }

    private fun toggle() {
        if (Stats.running) {
            startService(Intent(this, AdVpnService::class.java).setAction(AdVpnService.ACTION_STOP))
        } else {
            val i = VpnService.prepare(this)
            if (i != null) vpnPermission.launch(i) else startVpn()
        }
    }

    private fun startVpn() {
        startService(Intent(this, AdVpnService::class.java))
    }

    private fun fmt(n: Long): String = NumberFormat.getInstance().format(n)

    private fun refresh() {
        val run = Stats.running
        val t = Stats.total.get()
        val b = Stats.blocked.get()
        tvBlocked.text = fmt(b)
        tvTotal.text = fmt(t)
        tvPercent.text = if (t > 0) "${b * 100 / t}%" else "0%"
        tvFilter.text = "Filter aktif: ${fmt(BlockList.size.toLong())} domain"
        if (lastRunning != run) {
            lastRunning = run
            applyState(run)
        }
    }

    private fun applyState(run: Boolean) {
        powerBtn.setBackgroundResource(if (run) R.drawable.bg_power_on else R.drawable.bg_power_off)
        tvStatus.text = if (run) "TERLINDUNGI" else "NONAKTIF"
        tvStatus.setTextColor(getColor(if (run) R.color.ok else R.color.muted))
        tvHint.text = if (run) "Iklan & pelacak diblokir lewat DNS" else "Ketuk tombol untuk mengaktifkan"
        pulse?.cancel()
        if (run) {
            pulse = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 2200
                repeatCount = ValueAnimator.INFINITE
                addUpdateListener { v ->
                    val f = v.animatedValue as Float
                    val g = (f + 0.5f) % 1f
                    ring1.scaleX = 1f + 0.5f * f; ring1.scaleY = 1f + 0.5f * f; ring1.alpha = 0.6f * (1f - f)
                    ring2.scaleX = 1f + 0.5f * g; ring2.scaleY = 1f + 0.5f * g; ring2.alpha = 0.6f * (1f - g)
                }
                start()
            }
        } else {
            ring1.alpha = 0f
            ring2.alpha = 0f
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showLog() {
        val items = Stats.snapshot()
        if (items.isEmpty()) {
            toast("Belum ada query. Aktifkan lalu buka aplikasi.")
            return
        }
        val labels = items.map { (if (it.blocked) "🚫  " else "✅  ") + it.domain + "  ×" + it.count }
        MaterialAlertDialogBuilder(this)
            .setTitle("Log DNS — ketuk untuk blokir/izinkan")
            .setItems(labels.toTypedArray()) { _, i -> confirmToggle(items[i]) }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun confirmToggle(e: Stats.Entry) {
        val block = !e.blocked
        MaterialAlertDialogBuilder(this)
            .setTitle(if (block) "Blokir domain ini?" else "Izinkan domain ini?")
            .setMessage(e.domain + "\n(termasuk semua subdomain-nya)")
            .setPositiveButton(if (block) "Blokir" else "Izinkan") { _, _ ->
                if (block) BlockList.addCustom(this, e.domain) else BlockList.addAllow(this, e.domain)
                toast("Tersimpan. Jika masih muncul, tutup lalu buka ulang aplikasinya.")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showCustom() {
        val items = ArrayList<Pair<String, Boolean>>()
        BlockList.customList().forEach { items.add(it to true) }
        BlockList.allowList().forEach { items.add(it to false) }
        val b = MaterialAlertDialogBuilder(this).setTitle("Domain Kustom — ketuk untuk hapus")
        if (items.isEmpty()) {
            b.setMessage("Belum ada. Tambahkan domain iklan milik aplikasi tertentu, mis. ads.namaaplikasi.com")
        } else {
            val labels = items.map { (if (it.second) "🚫  " else "✅  ") + it.first }.toTypedArray()
            b.setItems(labels) { _, i ->
                BlockList.remove(this, items[i].first)
                toast("Dihapus: ${items[i].first}")
            }
        }
        b.setPositiveButton("Tambah") { _, _ -> showAdd() }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun showAdd() {
        val et = EditText(this).apply {
            hint = "contoh: ads.namaaplikasi.com"
            setTextColor(Color.WHITE)
            setHintTextColor(getColor(R.color.muted))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(et)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Tambah domain")
            .setView(box)
            .setPositiveButton("Blokir") { _, _ ->
                toast(if (BlockList.addCustom(this, et.text.toString())) "Domain diblokir" else "Domain tidak valid")
            }
            .setNeutralButton("Izinkan") { _, _ ->
                toast(if (BlockList.addAllow(this, et.text.toString())) "Domain diizinkan" else "Domain tidak valid")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun updateFilters() {
        toast("Mengunduh filter…")
        Thread {
            try {
                val n = BlockList.updateRemote(applicationContext)
                runOnUiThread { toast("Filter diperbarui: ${fmt(n.toLong())} domain") }
            } catch (e: Exception) {
                runOnUiThread { toast("Gagal mengunduh. Periksa koneksi internet.") }
            }
        }.start()
    }

    private fun chooseDns() {
        val names = arrayOf(
            "AdGuard DNS (94.140.14.14)", "Cloudflare (1.1.1.1)", "Google (8.8.8.8)", "Quad9 (9.9.9.9)"
        )
        val ips = arrayOf("94.140.14.14", "1.1.1.1", "8.8.8.8", "9.9.9.9")
        val p = getSharedPreferences("adshield", MODE_PRIVATE)
        val cur = ips.indexOf(p.getString("dns", ips[0])).coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle("Server DNS upstream")
            .setSingleChoiceItems(names, cur) { d, i ->
                p.edit().putString("dns", ips[i]).apply()
                toast("DNS: ${names[i]}")
                d.dismiss()
            }
            .show()
    }
}
