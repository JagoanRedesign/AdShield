package com.adshield.app

object DnsUtil {
    class Question(val name: String, val qtype: Int, val end: Int)

    fun parseQuestion(d: ByteArray): Question? {
        val len = d.size
        if (len < 12) return null
        val qd = ((d[4].toInt() and 0xFF) shl 8) or (d[5].toInt() and 0xFF)
        if (qd < 1) return null
        var pos = 12
        val sb = StringBuilder()
        while (true) {
            if (pos >= len) return null
            val l = d[pos].toInt() and 0xFF
            if (l == 0) { pos++; break }
            if ((l and 0xC0) != 0) return null
            pos++
            if (pos + l > len) return null
            for (i in 0 until l) sb.append((d[pos + i].toInt() and 0xFF).toChar())
            sb.append('.')
            pos += l
        }
        if (pos + 4 > len) return null
        val qtype = ((d[pos].toInt() and 0xFF) shl 8) or (d[pos + 1].toInt() and 0xFF)
        val name = sb.toString().trimEnd('.')
        return Question(name, qtype, pos + 4)
    }

    /** Jawaban untuk domain terblokir: A -> 0.0.0.0, tipe lain -> kosong (NOERROR). */
    fun blockedResponse(q: ByteArray, qu: Question): ByteArray {
        val isA = qu.qtype == 1
        val out = ByteArray(qu.end + if (isA) 16 else 0)
        System.arraycopy(q, 0, out, 0, qu.end)
        val rd = q[2].toInt() and 0x01
        out[2] = (0x80 or rd).toByte()
        out[3] = 0x80.toByte()
        out[4] = 0; out[5] = 1
        out[6] = 0; out[7] = if (isA) 1 else 0
        out[8] = 0; out[9] = 0; out[10] = 0; out[11] = 0
        if (isA) {
            var p = qu.end
            out[p++] = 0xC0.toByte(); out[p++] = 0x0C
            out[p++] = 0; out[p++] = 1          // TYPE A
            out[p++] = 0; out[p++] = 1          // CLASS IN
            out[p++] = 0; out[p++] = 0; out[p++] = 0; out[p++] = 30  // TTL
            out[p++] = 0; out[p++] = 4          // RDLENGTH
            out[p++] = 0; out[p++] = 0; out[p++] = 0; out[p] = 0
        }
        return out
    }

    fun udpPacket(src: ByteArray, dst: ByteArray, srcPort: Int, dstPort: Int, payload: ByteArray): ByteArray {
        val total = 28 + payload.size
        val p = ByteArray(total)
        p[0] = 0x45
        p[2] = (total shr 8).toByte(); p[3] = total.toByte()
        p[6] = 0x40
        p[8] = 64; p[9] = 17
        System.arraycopy(src, 0, p, 12, 4)
        System.arraycopy(dst, 0, p, 16, 4)
        var sum = 0
        var i = 0
        while (i < 20) {
            sum += ((p[i].toInt() and 0xFF) shl 8) or (p[i + 1].toInt() and 0xFF)
            i += 2
        }
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val ck = sum.inv() and 0xFFFF
        p[10] = (ck shr 8).toByte(); p[11] = ck.toByte()
        val ulen = 8 + payload.size
        p[20] = (srcPort shr 8).toByte(); p[21] = srcPort.toByte()
        p[22] = (dstPort shr 8).toByte(); p[23] = dstPort.toByte()
        p[24] = (ulen shr 8).toByte(); p[25] = ulen.toByte()
        System.arraycopy(payload, 0, p, 28, payload.size)
        return p
    }
}
