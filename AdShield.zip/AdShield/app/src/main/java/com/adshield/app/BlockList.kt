package com.adshield.app

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object BlockList {
    @Volatile private var base: Set<String> = emptySet()
    @Volatile private var custom: Set<String> = emptySet()
    @Volatile private var allow: Set<String> = emptySet()
    @Volatile private var loaded = false

    val size: Int get() = base.size + custom.size

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("adshield", Context.MODE_PRIVATE)

    @Synchronized
    fun load(ctx: Context, force: Boolean = false) {
        if (loaded && !force) return
        val set = HashSet<String>(120_000)
        ctx.resources.openRawResource(R.raw.blocklist).bufferedReader().useLines { ls ->
            ls.forEach { addLine(set, it) }
        }
        val f = File(ctx.filesDir, "remote.txt")
        if (f.exists()) f.bufferedReader().useLines { ls -> ls.forEach { addLine(set, it) } }
        base = set
        val p = prefs(ctx)
        custom = HashSet(p.getStringSet("custom", emptySet()) ?: emptySet())
        allow = HashSet(p.getStringSet("allow", emptySet()) ?: emptySet())
        loaded = true
    }

    private fun addLine(set: MutableSet<String>, raw: String) {
        val d = parseLine(raw) ?: return
        set.add(d)
    }

    /** Mendukung format hosts ("0.0.0.0 domain"), daftar domain polos, dan "||domain^" (AdGuard). */
    fun parseLine(raw: String): String? {
        var l = raw.trim()
        if (l.isEmpty() || l[0] == '#' || l[0] == '!') return null
        val h = l.indexOf('#')
        if (h > 0) l = l.substring(0, h).trim()
        if (l.startsWith("||")) {
            if (!l.endsWith("^")) return null
            l = l.substring(2, l.length - 1)
        } else {
            val parts = l.split(Regex("\\s+"))
            l = when {
                parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1") -> parts[1]
                parts.size == 1 -> parts[0]
                else -> return null
            }
        }
        l = l.lowercase().trimEnd('.')
        if (l.length < 4 || !l.contains('.')) return null
        if (l.all { it.isDigit() || it == '.' }) return null
        if (l.any { it == '/' || it == '*' || it == ':' || it == '^' || it == '$' || it == '|' }) return null
        return l
    }

    fun isBlocked(name: String): Boolean {
        val d = name.lowercase().trimEnd('.')
        if (matches(allow, d)) return false
        return matches(custom, d) || matches(base, d)
    }

    private fun matches(s: Set<String>, domain: String): Boolean {
        if (s.isEmpty()) return false
        var d = domain
        while (true) {
            if (s.contains(d)) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }

    fun customList(): List<String> = custom.sorted()
    fun allowList(): List<String> = allow.sorted()

    fun norm(s: String): String? {
        val d = s.trim().lowercase()
            .removePrefix("http://").removePrefix("https://")
            .substringBefore('/').trimEnd('.')
        return if (d.length > 3 && d.contains('.') && !d.contains(' ')) d else null
    }

    @Synchronized
    fun addCustom(ctx: Context, input: String): Boolean {
        val d = norm(input) ?: return false
        custom = custom + d
        allow = allow - d
        save(ctx)
        return true
    }

    @Synchronized
    fun addAllow(ctx: Context, input: String): Boolean {
        val d = norm(input) ?: return false
        allow = allow + d
        custom = custom - d
        save(ctx)
        return true
    }

    @Synchronized
    fun remove(ctx: Context, d: String) {
        custom = custom - d
        allow = allow - d
        save(ctx)
    }

    private fun save(ctx: Context) {
        prefs(ctx).edit()
            .putStringSet("custom", HashSet(custom))
            .putStringSet("allow", HashSet(allow))
            .apply()
    }

    /** Unduh daftar filter terbaru. Mengembalikan jumlah domain. */
    fun updateRemote(ctx: Context): Int {
        val urls = listOf(
            "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
            "https://adguardteam.github.io/HostlistsRegistry/assets/filter_1.txt"
        )
        val out = HashSet<String>()
        var ok = 0
        for (u in urls) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.inputStream.bufferedReader().useLines { ls -> ls.forEach { addLine(out, it) } }
                c.disconnect()
                ok++
            } catch (e: Exception) {
                // lewati sumber yang gagal
            }
        }
        if (ok == 0) throw IOException("Gagal mengunduh filter")
        File(ctx.filesDir, "remote.txt").writeText(out.joinToString("\n"))
        load(ctx, true)
        return out.size
    }
}
