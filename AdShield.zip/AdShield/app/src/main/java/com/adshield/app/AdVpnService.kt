package com.adshield.app

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class AdVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private val pool: ExecutorService = Executors.newFixedThreadPool(8)
    @Volatile private var active = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            return START_NOT_STICKY
        }
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (active) return
        BlockList.load(this)
        val b = Builder()
            .setSession("AdShield")
            .setMtu(1500)
            .setBlocking(true)
            .addAddress(VPN_ADDR, 32)
            .addDnsServer(VPN_DNS)
            .addRoute(VPN_DNS, 32)
        // Alihkan juga DNS publik populer agar aplikasi dengan DNS bawaan tetap tersaring
        for (ip in EXTRA_DNS) b.addRoute(ip, 32)
        val fd = try { b.establish() } catch (e: Exception) { null }
        if (fd == null) {
            stopSelf()
            return
        }
        tun = fd
        active = true
        Stats.running = true
        worker = Thread({ loop(fd) }, "adshield-loop").also { it.start() }
    }

    private fun loop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (active) {
                val n = input.read(buf)
                if (n < 0) break
                if (n == 0) continue
                handlePacket(buf, n, output)
            }
        } catch (e: Exception) {
            // tun ditutup
        } finally {
            if (tun === fd) stopVpn()
        }
    }

    private fun handlePacket(buf: ByteArray, n: Int, out: FileOutputStream) {
        if (n < 28 || (buf[0].toInt() shr 4) != 4) return
        val ihl = (buf[0].toInt() and 0x0F) * 4
        if (buf[9].toInt() != 17 || n < ihl + 8) return
        val srcPort = ((buf[ihl].toInt() and 0xFF) shl 8) or (buf[ihl + 1].toInt() and 0xFF)
        val dstPort = ((buf[ihl + 2].toInt() and 0xFF) shl 8) or (buf[ihl + 3].toInt() and 0xFF)
        if (dstPort != 53) return
        val udpLen = ((buf[ihl + 4].toInt() and 0xFF) shl 8) or (buf[ihl + 5].toInt() and 0xFF)
        val plen = minOf(udpLen - 8, n - ihl - 8)
        if (plen <= 0) return
        val srcIp = buf.copyOfRange(12, 16)
        val dstIp = buf.copyOfRange(16, 20)
        val q = buf.copyOfRange(ihl + 8, ihl + 8 + plen)

        val qu = DnsUtil.parseQuestion(q)
        if (qu != null) {
            val blocked = BlockList.isBlocked(qu.name)
            Stats.add(qu.name, blocked)
            if (blocked) {
                reply(out, dstIp, srcIp, srcPort, DnsUtil.blockedResponse(q, qu))
                return
            }
        }
        pool.execute { forward(q, out, dstIp, srcIp, srcPort) }
    }

    private fun reply(out: FileOutputStream, fromIp: ByteArray, toIp: ByteArray, toPort: Int, payload: ByteArray) {
        val pkt = DnsUtil.udpPacket(fromIp, toIp, 53, toPort, payload)
        try {
            synchronized(out) { out.write(pkt) }
        } catch (e: Exception) {
        }
    }

    private fun forward(q: ByteArray, out: FileOutputStream, fromIp: ByteArray, toIp: ByteArray, toPort: Int) {
        var s: DatagramSocket? = null
        try {
            s = DatagramSocket()
            protect(s)
            s.soTimeout = 4000
            val upstream = getSharedPreferences("adshield", MODE_PRIVATE).getString("dns", "94.140.14.14")!!
            s.send(DatagramPacket(q, q.size, InetAddress.getByName(upstream), 53))
            val r = ByteArray(4096)
            val p = DatagramPacket(r, r.size)
            s.receive(p)
            reply(out, fromIp, toIp, toPort, r.copyOf(p.length))
        } catch (e: Exception) {
        } finally {
            s?.close()
        }
    }

    private fun stopVpn() {
        active = false
        Stats.running = false
        try { tun?.close() } catch (e: Exception) { }
        tun = null
        stopSelf()
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        pool.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.adshield.app.STOP"
        private const val VPN_ADDR = "10.0.0.2"
        private const val VPN_DNS = "10.0.0.1"
        private val EXTRA_DNS = listOf(
            "8.8.8.8", "8.8.4.4", "1.1.1.1", "1.0.0.1", "9.9.9.9", "94.140.14.14", "94.140.15.15"
        )
    }
}
