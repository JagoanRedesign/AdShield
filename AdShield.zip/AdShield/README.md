# AdShield
Pemblokir iklan & pelacak lewat DNS (VpnService lokal, tanpa root).
Build: unggah AdShield.zip + build.yml (di .github/workflows/) ke repo, lalu jalankan Actions > Build APK.
APK ada di Artifacts (AdShield-APK).
